package snakebattleonline;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.ArrayDeque;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.UIManager;

/*
    TO DO:

        Add functionality for players leaving.

*/

public class Server {
    // Graphics
    private static JFrame frame;
    private static JPanel panel;
    private static JLabel portLabel;
    private static JTextField portField;
    private static JButton startButton;
    private static JLabel ipLabel;
    // Server state graphics
    private static JPanel serverStatePanel;
    private static JTextArea serverStateArea;
    private static JButton stopServerButton;

    // Network
    private static InetAddress localHost;
    private static ArrayList<Integer> ports = new ArrayList<>();
    private static ArrayList<InetAddress> clients = new ArrayList<>();
    private static ArrayList<NetworkBroadcaster> broadcasters = new ArrayList<>();

    // Game parameters
    private static int serverport;

    // Game state
    private static boolean gameStartLatch = false;
    private static javax.swing.Timer timer;
    // private static int framesElapsed = 0;
    private static boolean appleEatenThisFrame = false;
    private static int[] snake1Pos = { 2, 35 };
    private static int[] snake2Pos = { 61, 4 };
    private static int[] snake3Pos = { 2, 4 };
    private static int[] snake4Pos = { 61, 35 };
    private static dir[] snakeDirs = { dir.RIGHT, dir.LEFT, dir.RIGHT, dir.LEFT };

    private static int[] applePos = { -1, -1 };
    private static boolean goldenApple = false;
    private static int[] snakeLengths = { 4, 4, 4, 4 };

    // powerups
    private static Powerup powerup = new Powerup();
    private static boolean[] isFrozen = { false, false, false, false };
    private static int frozenTimer = 0;
    private static int blindTimer = 0;
    private static boolean[] isBlind = { false, false, false, false };

    private static int[][] head;
    private static boolean[] death = { false, false, false, false };
    private static int deathCount = 0;
    private static int[] wins = { 0, 0, 0, 0 };

    private static ArrayList<ArrayList<int[]>> tail = new ArrayList<>();
    private static List<Queue<dir>> inputQueues = new ArrayList<>(4);
    private static int[] lastMove = { -1, -1, -1, -1 };

    private static String[] allQCStrings = { "", "", "", "" };
    private static String[] lastQCSent = { "", "", "", "" }; // Track last sent QC to prevent duplicate logging
    private static int[] qcDisplayTimer = { 0, 0, 0, 0 }; // frames to display each quick chat

    /*
     * Launches a server parameter window. User can input desired port number.
     * IP defaults to current computer's ip address and cannot be changed for
     * obvious reasons.
     * 
     * Start server button launches a server and begins listening for clients to
     * join.
     * This opens a server state window that shows the state of the game and client
     * connections.
     * 
     * Server can only be closed by hitting the stop server button. The X button
     * cannot
     * be used. This is to prevent any accidental closures or network errors that
     * may
     * arise from improper shutdown protocol.
     */

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        // powerup initialization
        powerup.generate(-1, -1, -1);
        // input queues initialization
        for (int i = 0; i < 4; i++) {
            inputQueues.add(new ArrayDeque<>());
        }
        // Server initialization
        try {
            localHost = InetAddress.getLocalHost();
        } catch (Exception e) {
            e.printStackTrace();
        }
        frame = new JFrame("Snake Battle Online - Server");
        panel = new JPanel();

        portLabel = new JLabel("Port:");
        portField = new JTextField("1234", 4);
        startButton = new JButton("Start Server");
        ipLabel = new JLabel("Server IP: " + localHost.getHostAddress());

        panel.add(portLabel);
        panel.add(portField);
        panel.add(startButton);
        panel.add(ipLabel);

        serverStatePanel = new JPanel();
        serverStateArea = new JTextArea(10, 30);
        serverStateArea.setEditable(false);
        stopServerButton = new JButton("Stop Server");
        serverStatePanel.add(new JScrollPane(serverStateArea));
        serverStatePanel.add(stopServerButton);

        frame.add(panel);
        frame.setSize(400, 120);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        startButton.addActionListener(e -> {
            try {
                serverport = Integer.parseInt(portField.getText());
                frame.remove(panel);
                frame.add(serverStatePanel);
                frame.revalidate();
                frame.repaint();
                frame.setSize(400, 300);
                frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
                serverFunction();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Invalid port number!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        });
        stopServerButton.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(frame, "Are you sure you want to stop the server?",
                    "Confirm Stop",
                    JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                broadCastToAllClients("Server stopped".getBytes());
                System.exit(0);
            }
        });

        // server state driver

        timer = new javax.swing.Timer(65,
                new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (gameStartLatch) {
                            updateGame();
                            // framesElapsed++;
                        }
                    }

                });
        timer.start();
    }

    /*
     * @post updates game state and broadcasts to clients every frame.
     */
    public static void updateGame() {
        handleGameState();
        broadCastToAllClients(getGameStateData());
    }

    /*
     * @post handles the game state updates and collision detection.
     */
    public static void handleGameState() {
        appleEatenThisFrame = false;
        head = new int[][] {
                death[0] ? null : snake1Pos,
                death[1] ? null : snake2Pos,
                death[2] ? null : snake3Pos,
                death[3] ? null : snake4Pos
        };
        // snakes - only move snakes that have connected clients
        // change directions based on input queues to prevent multiple inputs per frame
        for (int s = 0; s < clients.size(); s++) {
            if (!isFrozen[s] && !inputQueues.get(s).isEmpty()) {
                snakeDirs[s] = inputQueues.get(s).poll();
            }
        }

        // frozen timer
        boolean anyFrozen = false;
        for (int s = 0; s < clients.size(); s++) {
            if (isFrozen[s]) {
                anyFrozen = true;
                break;
            }
        }
        if (anyFrozen) {
            frozenTimer++;
            if (frozenTimer >= 100) {
                for (int s = 0; s < clients.size(); s++) {
                    isFrozen[s] = false;
                }
                frozenTimer = 0;
            }
        }

        // blind timer
        boolean anyBlind = false;
        for (int s = 0; s < clients.size(); s++) {
            if (isBlind[s]) {
                anyBlind = true;
                break;
            }
        }
        if (anyBlind) {
            blindTimer++;
            if (blindTimer >= 50) {
                for (int s = 0; s < clients.size(); s++) {
                    isBlind[s] = false;
                }
                blindTimer = 0;
            }
        }

        if (clients.size() > 0 && head[0] != null && !isFrozen[0]) {
            switch (snakeDirs[0]) {
                case UP -> {
                    snake1Pos[1]--;
                    if (snake1Pos[1] < 2) {
                        snake1Pos[1] = 37;
                    }
                }
                case DOWN -> {
                    snake1Pos[1]++;
                    if (snake1Pos[1] > 37) {
                        snake1Pos[1] = 2;
                    }
                }
                case LEFT -> {
                    snake1Pos[0]--;
                    if (snake1Pos[0] < 2) {
                        snake1Pos[0] = 61;
                    }
                }
                case RIGHT -> {
                    snake1Pos[0]++;
                    if (snake1Pos[0] > 61) {
                        snake1Pos[0] = 2;
                    }
                }
            }
        }
        if (clients.size() > 1 && head[1] != null && !isFrozen[1]) {
            switch (snakeDirs[1]) {
                case UP -> {
                    snake2Pos[1]--;
                    if (snake2Pos[1] < 2) {
                        snake2Pos[1] = 37;
                    }
                }
                case DOWN -> {
                    snake2Pos[1]++;
                    if (snake2Pos[1] > 37) {
                        snake2Pos[1] = 2;
                    }
                }
                case LEFT -> {
                    snake2Pos[0]--;
                    if (snake2Pos[0] < 2) {
                        snake2Pos[0] = 61;
                    }
                }
                case RIGHT -> {
                    snake2Pos[0]++;
                    if (snake2Pos[0] > 61) {
                        snake2Pos[0] = 2;
                    }
                }
            }
        }
        if (clients.size() > 2 && head[2] != null && !isFrozen[2]) {
            switch (snakeDirs[2]) {
                case UP -> {
                    snake3Pos[1]--;
                    if (snake3Pos[1] < 2) {
                        snake3Pos[1] = 37;
                    }
                }
                case DOWN -> {
                    snake3Pos[1]++;
                    if (snake3Pos[1] > 37) {
                        snake3Pos[1] = 2;
                    }
                }
                case LEFT -> {
                    snake3Pos[0]--;
                    if (snake3Pos[0] < 2) {
                        snake3Pos[0] = 61;
                    }
                }
                case RIGHT -> {
                    snake3Pos[0]++;
                    if (snake3Pos[0] > 61) {
                        snake3Pos[0] = 2;
                    }
                }
            }
        }
        if (clients.size() > 3 && head[3] != null && !isFrozen[3]) {
            switch (snakeDirs[3]) {
                case UP -> {
                    snake4Pos[1]--;
                    if (snake4Pos[1] < 2) {
                        snake4Pos[1] = 37;
                    }
                }
                case DOWN -> {
                    snake4Pos[1]++;
                    if (snake4Pos[1] > 37) {
                        snake4Pos[1] = 2;
                    }
                }
                case LEFT -> {
                    snake4Pos[0]--;
                    if (snake4Pos[0] < 2) {
                        snake4Pos[0] = 61;
                    }
                }
                case RIGHT -> {
                    snake4Pos[0]++;
                    if (snake4Pos[0] > 61) {
                        snake4Pos[0] = 2;
                    }
                }
            }
        }
        for (int s = 0; s < clients.size(); s++) {
            if (head[s] == null || death[s]) {
                continue;
            }
            while (tail.get(s).size() < snakeLengths[s]) {
                tail.get(s).add(new int[] { -1, -1 });
            }
            if (tail.get(s).size() > 0 && !isFrozen[s]) {
                for (int i = tail.get(s).size() - 1; i >= 1; i--) {
                    tail.get(s).get(i)[0] = tail.get(s).get(i - 1)[0];
                    tail.get(s).get(i)[1] = tail.get(s).get(i - 1)[1];
                }
                tail.get(s).get(0)[0] = head[s][0];
                tail.get(s).get(0)[1] = head[s][1];
            }
        }
        // apple
        if (applePos[0] == -1 && !appleEatenThisFrame) {// generate apple
            if (Math.random() < 0.05) {
                goldenApple = true;
            }
            int x;
            int y;
            do {
                x = (int) (Math.random() * 60) + 2;
                y = (int) (Math.random() * 35) + 2;
            } while (!invalidCoord(x, y));
            applePos[0] = x;
            applePos[1] = y;
        }
        for (int s = 0; s < clients.size(); s++) {// eats apple - only connected snakes
            if (head[s] == null || death[s]) {
                continue;
            }
            if (applePos[0] == head[s][0] && applePos[1] == head[s][1]) {// eats apple
                applePos[0] = -1;
                appleEatenThisFrame = true;
                if (goldenApple) {
                    goldenApple = false;
                    snakeLengths[s] += (int) (Math.random() * 20 + 1);
                } else {
                    snakeLengths[s]++;
                }
            }
        }
        // spawn powerup!
        if (powerup.getType() == -1 && Math.random() < 0.005) {
            int x;
            int y;
            int t;
            do {
                x = (int) (Math.random() * 60) + 2;
                y = (int) (Math.random() * 35) + 2;
            } while (!invalidCoord(x, y));
            t = (int) (Math.random() * powerup.getNum()) + 1;
            // 1 -> freeze
            // 2 -> blind
            // 3 -> portal
            // 4 -> randomdir
            if (t == 3) {
                int ox;
                int oy;
                do {
                    ox = (int) (Math.random() * 60) + 2;
                    oy = (int) (Math.random() * 35) + 2;
                } while (!invalidCoord(ox, oy));
                powerup.generate(x, y, ox, oy, t);
            } else {
                powerup.generate(x, y, t);
            }
        }
        // eats powerup!
        for (int s = 0; s < clients.size(); s++) {
            if (head[s] == null || death[s]) {
                continue;
            }
            if (head[s][0] == powerup.getX() && head[s][1] == powerup.getY()) {
                switch (powerup.getType()) {
                    case 1 -> {// freeze
                        for (int os = 0; os < clients.size(); os++) {
                            if (os == s || head[os] == null || death[os]) {
                                continue;
                            }
                            isFrozen[os] = true;
                            frozenTimer = 0;
                        }
                    }
                    case 2 -> {// blind
                        for (int os = 0; os < clients.size(); os++) {
                            if (os == s || head[os] == null || death[os]) {
                                continue;
                            }
                            isBlind[os] = true;
                            blindTimer = 0;
                        }
                    }
                    case 3 -> {// portal
                        head[s][0] = powerup.getOtherX();
                        head[s][1] = powerup.getOtherY();
                    }
                    // case 4 -> {// randomdir
                    // for (int os = 0; os < clients.size(); os++) {
                    // if (os == s || head[os] == null || death[os]) {
                    // continue;
                    // }
                    // if(snakeDirs[os] == dir.RIGHT || snakeDirs[os] == dir.LEFT) {
                    // snakeDirs[os] = Math.random() < 0.5 ? dir.UP : dir.DOWN;
                    // } else {
                    // snakeDirs[os] = Math.random() < 0.5 ? dir.RIGHT : dir.LEFT;
                    // }
                    // inputQueues.get(os).clear(); // Clear queued inputs so forced direction takes
                    // effect
                    // }
                    // }
                }
                powerup.generate(-1, -1, -1);
                break;
            } else if (head[s][0] == powerup.getOtherX() && head[s][1] == powerup.getOtherY()
                    && powerup.getType() == 3) {
                head[s][0] = powerup.getX();
                head[s][1] = powerup.getY();
                powerup.generate(-1, -1, -1);
                break;
            }
        }
        // collision and death
        collisionManager();
        for (int s = 0; s < 4; s++) {
            if (head[s] != null && death[s]) {
                head[s] = null;
                if (s == 0) {
                    serverStateArea.append("Snake 1 died!\n");
                    snake1Pos[0] = -1;
                    snake1Pos[1] = -1;
                } else if (s == 1) {
                    serverStateArea.append("Snake 2 died!\n");
                    snake2Pos[0] = -1;
                    snake2Pos[1] = -1;
                } else if (s == 2) {
                    serverStateArea.append("Snake 3 died!\n");
                    snake3Pos[0] = -1;
                    snake3Pos[1] = -1;
                } else if (s == 3) {
                    serverStateArea.append("Snake 4 died!\n");
                    snake4Pos[0] = -1;
                    snake4Pos[1] = -1;
                }
                deathCount++;
            }
        }
        // win condition
        if (deathCount >= clients.size() - 1) {
            // pause the game for 2 seconds and then go back to start menus
            int winner = -1;
            for (int i = 0; i < clients.size(); i++) {
                if (!death[i]) {
                    winner = i + 1;
                    break;
                }
            }
            if (deathCount == clients.size()) {
                winner = -1;
                serverStateArea.append("Game ended! No winner!\n");
            } else {
                wins[winner - 1]++;
                serverStateArea.append("Game ended! Winner: Snake " + winner + "\n");
            }
            try {
                timer.stop();
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            gameStartLatch = false;

            resetGameState();
            broadCastToAllClients(getGameStateData());
            timer.start();
        }
    }

    /*
     * @param requires x and y coordinates
     * 
     * @post returns true if the coordinates are not occupied by a head/tail, apple,
     * or powerup.
     */
    private static boolean invalidCoord(int x, int y) {
        head = new int[][] {
                death[0] ? null : snake1Pos,
                death[1] ? null : snake2Pos,
                death[2] ? null : snake3Pos,
                death[3] ? null : snake4Pos
        };
        for (int s = 0; s < clients.size(); s++) {
            if (head[s] == null || death[s]) {
                continue;
            }
            if (x == head[s][0] && y == head[s][1]) {// check heads
                return false;
            }
            for (int i = 0; i < tail.get(s).size(); i++) {// check tails
                if (tail.get(s).get(i)[0] == x && tail.get(s).get(i)[1] == y) {
                    return false;
                }
            }
        }
        if (x == applePos[0] && y == applePos[1]) {// check apple
            return false;
        }
        if (powerup.getType() != -1) {
            if (x == powerup.getX() && y == powerup.getY()) {// check powerup
                return false;
            }
            if (x == powerup.getOtherX() && y == powerup.getOtherY() && powerup.getType() == 3) {
                return false;
            }
        }
        return true;
    }

    /*
     * @post handles detection of collision between snakes/self and updates death
     * states accordingly.
     */
    private static void collisionManager() {
        head = new int[][] {
                death[0] ? null : snake1Pos,
                death[1] ? null : snake2Pos,
                death[2] ? null : snake3Pos,
                death[3] ? null : snake4Pos
        };
        if (death[0] && death[1] && death[2] && death[3]) {
            return;// skip detection
        }
        for (int s = 0; s < clients.size(); s++) {
            if (head[s] == null || death[s]) {
                continue;
            }
            // check self collision
            inner: for (int i = 1; i < tail.get(s).size(); i++) {
                if (head[s][0] == tail.get(s).get(i)[0] && head[s][1] == tail.get(s).get(i)[1]) {
                    death[s] = true;
                    break inner;
                }
            }
            // check collision with other snake
            inner: for (int s2 = 0; s2 < clients.size(); s2++) {
                if (s == s2 || head[s2] == null || death[s2]) {
                    continue inner;
                }
                if (head[s][0] == head[s2][0] && head[s][1] == head[s2][1]) {
                    death[s] = true;
                    death[s2] = true;
                    continue inner;
                }
                for (int i = 0; i < tail.get(s2).size(); i++) {
                    if (head[s][0] == tail.get(s2).get(i)[0] && head[s][1] == tail.get(s2).get(i)[1]) {
                        death[s] = true;
                        continue inner;
                    }
                }
            }
        }
    }

    /*
     * @post handles initializations and starts server listening thread.
     */
    public static void serverFunction() {
        for (int i = 0; i < 4; i++) {
            tail.add(new ArrayList<>());
        }

        NetworkListener nl = new NetworkListener(serverport, 1024, new DataReceiver() {
            @Override
            public void onReceive(byte[] data, InetAddress address, int port) {
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                DataOutputStream dos = new DataOutputStream(baos);

                String messageType = new String(data).trim();

                if (messageType.equals("Connected")) {
                    serverStateArea.append("Client connected: " + address.getHostAddress() + ":" + port + "\n");
                    if (clients.size() < 4) {
                        ports.add((Integer) port);
                        clients.add(address);
                        broadcasters.add(new NetworkBroadcaster(address, port));
                        try {
                            dos.writeInt(clients.size());
                            broadcasters.get(broadcasters.size() - 1).broadcast(baos.toByteArray());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        broadCastToAllClients(getGameStateData());
                    } else {
                        try {
                            dos.writeInt(-1);
                            NetworkBroadcaster tempNb = new NetworkBroadcaster(address, port);
                            tempNb.broadcast(baos.toByteArray());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    return;
                }

                if (messageType.equals("Start game")) {
                    gameStartLatch = true;
                    serverStateArea.append("Game started!\n");
                    broadCastToAllClients(getGameStateData());
                    return;
                }

                // If not a known text command, treat as binary game state message
                try {
                    ByteArrayInputStream bais = new ByteArrayInputStream(data);
                    DataInputStream dis = new DataInputStream(bais);

                    boolean gameStateMessage = dis.readBoolean();
                    int sender = dis.readInt();

                    if (sender >= 1 && sender <= 4 && gameStartLatch) {
                        int temp = dis.readInt();
                        if (temp != lastMove[sender - 1]) {
                            inputQueues.get(sender - 1).add(dir.values()[temp]);
                        }
                        snakeLengths[sender - 1] = dis.readInt();
                        String rc_qcString = dis.readUTF();
                        if (!rc_qcString.isEmpty() && !rc_qcString.equals(lastQCSent[sender - 1])) {
                            serverStateArea.append("Snake " + sender + ": " + rc_qcString + "\n");
                            qcDisplayTimer[sender - 1] = 100; // Display for 100 frames
                        }
                        allQCStrings[sender - 1] = rc_qcString;
                        lastQCSent[sender - 1] = rc_qcString;
                        lastMove[sender - 1] = temp;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        nl.start();
        serverStateArea.append("Server started on " + localHost.getHostAddress() + ":" + serverport + "\n");
    }

    /*
     * @param requires a byte array containing data that will be sent to clients.
     * Must fit a certain format.
     * 
     * @post broadcasts the data to all connected clients.
     */
    public static void broadCastToAllClients(byte[] data) {
        for (int i = 0; i < broadcasters.size(); i++) {
            try {
                broadcasters.get(i).broadcast(data);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /*
     * @post packages the current game state into a byte array usable by clients.
     */
    public static byte[] getGameStateData() {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        try {
            // gamestate
            dos.writeBoolean(gameStartLatch);
            dos.writeInt(clients.size());
            // snake data
            dos.writeInt(snake1Pos[0]);
            dos.writeInt(snake1Pos[1]);
            dos.writeInt(snakeLengths[0]);
            dos.writeInt(snake2Pos[0]);
            dos.writeInt(snake2Pos[1]);
            dos.writeInt(snakeLengths[1]);
            dos.writeInt(snake3Pos[0]);
            dos.writeInt(snake3Pos[1]);
            dos.writeInt(snakeLengths[2]);
            dos.writeInt(snake4Pos[0]);
            dos.writeInt(snake4Pos[1]);
            dos.writeInt(snakeLengths[3]);
            // apple
            dos.writeInt(applePos[0]);
            dos.writeInt(applePos[1]);
            dos.writeBoolean(goldenApple);
            // death state
            dos.writeBoolean(death[0]);
            dos.writeBoolean(death[1]);
            dos.writeBoolean(death[2]);
            dos.writeBoolean(death[3]);
            // series data
            dos.writeInt(wins[0]);
            dos.writeInt(wins[1]);
            dos.writeInt(wins[2]);
            dos.writeInt(wins[3]);
            // quickchats
            for (int i = 0; i < 4; i++) {
                if (qcDisplayTimer[i] > 0) {
                    qcDisplayTimer[i]--;
                    dos.writeUTF(allQCStrings[i] == null ? "" : allQCStrings[i]);
                } else {
                    allQCStrings[i] = "";
                    dos.writeUTF("");
                }
            }
            // powerups
            dos.writeInt(powerup.getType());
            dos.writeInt(powerup.getX());
            dos.writeInt(powerup.getY());
            dos.writeInt(powerup.getOtherX());
            dos.writeInt(powerup.getOtherY());
            dos.writeBoolean(isFrozen[0]);
            dos.writeBoolean(isFrozen[1]);
            dos.writeBoolean(isFrozen[2]);
            dos.writeBoolean(isFrozen[3]);
            dos.writeBoolean(isBlind[0]);
            dos.writeBoolean(isBlind[1]);
            dos.writeBoolean(isBlind[2]);
            dos.writeBoolean(isBlind[3]);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return baos.toByteArray();
    }

    /*
     * @post resets game state back to default.
     */
    private static void resetGameState() {

        // Game state
        // framesElapsed = 0;
        appleEatenThisFrame = false;
        // border is 2
        head = null;
        snake1Pos = null;
        snake2Pos = null;
        snake3Pos = null;
        snake4Pos = null;
        snake1Pos = new int[] { 2, 35 };
        snake2Pos = new int[] { 61, 4 };
        snake3Pos = new int[] { 2, 4 };
        snake4Pos = new int[] { 61, 35 };
        snakeDirs = new dir[] { dir.RIGHT, dir.LEFT, dir.RIGHT, dir.LEFT };

        applePos = new int[] { -1, -1 };
        goldenApple = false;
        snakeLengths = new int[] { 4, 4, 4, 4 };

        death = new boolean[] { false, false, false, false };
        deathCount = 0;
        allQCStrings = new String[] { "", "", "", "" };
        lastQCSent = new String[] { "", "", "", "" };
        qcDisplayTimer = new int[] { 0, 0, 0, 0 };

        tail.clear();
        isFrozen = new boolean[] { false, false, false, false };
        isBlind = new boolean[] { false, false, false, false };
        powerup.generate(-1, -1, -1);
        for (int i = 0; i < clients.size(); i++) {
            inputQueues.get(i).clear();
            lastMove[i] = -1;
            tail.add(new ArrayList<int[]>());
        }
        lastMove = new int[] { -1, -1, -1, -1 };

        head = new int[][] { snake1Pos, snake2Pos, snake3Pos, snake4Pos };
    }
}
/*

    




*/