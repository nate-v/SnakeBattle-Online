package snakebattleonline;

public enum dir {
    UP, DOWN, LEFT, RIGHT
}
