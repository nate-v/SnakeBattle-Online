package snakebattleonline;

/* ▄▄     ▄▄▄                 ▄▄▄             ▄▄                  
   ██▄   ██▀      █▄         █▀██  ██▀▀        ██              █▄ 
   ███▄  ██      ▄██▄          ██  ██       ▀▀ ██ ▀▀ ▄▄     ▀▀▄██▄
   ██ ▀█▄██ ▄▀▀█▄ ██ ▄█▀█▄     ██  ██ ▄▀▀█▄ ██ ██ ██ ██ ▄█▀ ██ ██ 
   ██   ▀██ ▄█▀██ ██ ██▄█▀     ██▄ ██ ▄█▀██ ██ ██ ██ ████   ██ ██ 
 ▀██▀    ██▄▀█▄██▄██▄▀█▄▄▄      ▀███▀▄▀█▄██▄██▄██▄██▄██ ▀█▄▄██▄██*/

import javax.swing.*;

public class SnakeBattleOnline {
    private static JFrame frame;
    private static JPanel panel;
    private static JButton hostButton;
    private static JButton joinButton;
    private static JLabel titleLabel;

    private static Main main;
    private static Server server;
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        frame = new JFrame("Snake Battle Online");
        panel = new JPanel();
        hostButton = new JButton("Host Game");
        joinButton = new JButton("Join Game");
        titleLabel = new JLabel("Snake Battle Online");
        titleLabel.setFont(titleLabel.getFont().deriveFont(24.0f));
        panel.add(titleLabel);
        panel.add(hostButton);
        panel.add(joinButton);
        frame.add(panel);
        frame.setSize(300, 130);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        hostButton.addActionListener(e -> {
            server = new Server();
            server.main(null);
            frame.dispose();
        });
        joinButton.addActionListener(e -> {
            main = new Main();
            main.main(args);
            frame.dispose();
        });
    }
}
