package snakebattleonline;

public class Powerup {
   private int type = -1;
   private int owner = -1;// -1 is no owner
   private int n = 3; // number of powerups
   private int x;
   private int y;
   private int otherX;
   private int otherY;

   public void setOwner(int s) {
      owner = s;
   }

   public int getOwner() {
      return owner;
   }

   public int getType() {
      return type;
   }

   public int getNum() {
      return n;
   }

   public int getX() {
      return x;
   }

   public int getY() {
      return y;
   }

   public void generate(int x, int y, int t) {
      this.x = x;
      this.y = y;
      otherX = -1;
      otherY = -1;
      type = t;
   }

   public void generate(int x, int y, int ox, int oy, int t) {
      this.x = x;
      this.y = y;
      otherX = ox;
      otherY = oy;
      type = t;
   }

   public int getOtherX() {
      return otherX;
   }

   public int getOtherY() {
      return otherY;
   }

   public void setPortal(int x, int y) {
      otherX = x;
      otherY = y;
   }
}