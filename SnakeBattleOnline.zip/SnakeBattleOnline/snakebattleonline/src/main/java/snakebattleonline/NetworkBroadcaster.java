package snakebattleonline;

/* ▄▄     ▄▄▄                 ▄▄▄             ▄▄                  
   ██▄   ██▀      █▄         █▀██  ██▀▀        ██              █▄ 
   ███▄  ██      ▄██▄          ██  ██       ▀▀ ██ ▀▀ ▄▄     ▀▀▄██▄
   ██ ▀█▄██ ▄▀▀█▄ ██ ▄█▀█▄     ██  ██ ▄▀▀█▄ ██ ██ ██ ██ ▄█▀ ██ ██ 
   ██   ▀██ ▄█▀██ ██ ██▄█▀     ██▄ ██ ▄█▀██ ██ ██ ██ ████   ██ ██ 
 ▀██▀    ██▄▀█▄██▄██▄▀█▄▄▄      ▀███▀▄▀█▄██▄██▄██▄██▄██ ▀█▄▄██▄██

    TO DO:
    
*/

/*
    IN ORDER TO IMPLEMENT ON THE FCPS NETWORK:
    1. Open command prompt, run "ipconfig" and feed the IPv4 address
        into the ip variable in the constructor. NetworkListener does
        not need the ip because it listens on the port, not the address.
    2. Allow your JDK through the firewall, it likely will not prompt you.
        You must have administrator access. If you are on JGrasp, the
        bundled JDK is located in C:\Program Files(x86)\jGrasp\bundled\bin
        Allow java.exe and javaw.exe through the firewell for both private 
        and public networks.
    3. The port number can be whatever you want. It will crash if the port
        number is already in use. Open command prompt and run "netstat -a -n -o"
        to see all active ports. Do not use any ports in the UDP section.
    4. If it still does not work, create a new inbound rule by going to control panel ->
        system and security -> advanced settings -> inbound rules -> new inbound rule.
        Choose port, UDP, and either allow a specific port or all of them through public
        and private.
    5. After configuring your network, if it still does not work, check your implementation.

        TIP:
            If you want the server to talk back to clients without a fixed
            client port written into the server. Give the networklistener
            and the networkbroadcaster the same datagramsocket in the 
            constructor. OR you can seperately send client port and address
            information.

            Use ByteArray streams to send larger data packets with mulitple 
            variables.

    You can find a sample implementation of the NetworkListener and NetworkBroadcaster
    in the Server and Client classes provided in this folder.
*/

import java.io.IOException;
import java.net.*;

public class NetworkBroadcaster {
    private final int port;
    private final InetAddress serverAddress;
    private final DatagramSocket socket;

    /*
        CONSTRUCTORS
            - socket is optional, if not provided a new socket is made.
            - socket may be used for sharing a socket across classes.
    
    */
    public NetworkBroadcaster(String ip, int port) {
        this(resolveAddress(ip), port, createSocket());
    }

    public NetworkBroadcaster(String ip, int port, DatagramSocket socket) {
        this(resolveAddress(ip), port, socket);
    }

    public NetworkBroadcaster(InetAddress serverAddress, int port) {
        this(serverAddress, port, createSocket());
    }

    public NetworkBroadcaster(InetAddress serverAddress, int port, DatagramSocket socket) {
        validateArguments(serverAddress, port, socket);
        this.serverAddress = serverAddress;
        this.port = port;
        this.socket = socket;
    }

    /*
        MAIN FUNCTIONALITY
    */
    public void broadcast(byte[] data) {
        if(data == null) {
            throw new IllegalArgumentException("data must not be null");
        }
        try {
            DatagramPacket packet = new DatagramPacket(data, data.length, serverAddress, port);
            socket.send(packet);
        } catch(IOException e) {
            throw new IllegalStateException("Failed to send UDP packet", e);
        }
    }

    /*
        CLOSURE AND UTILITIES
    */
    public void close() {
        if(socket != null && !socket.isClosed()) {
            socket.close();
        }
    }

    //centralize error handling for address creation.
    private static InetAddress resolveAddress(String ip) {
        if(ip == null || ip.isBlank()) {
            throw new IllegalArgumentException("ip must not be null or blank");
        }
        try {
            return InetAddress.getByName(ip);
        } catch(IOException e) {
            throw new IllegalArgumentException("Unable to resolve host: " + ip, e);
        }
    }

    //Keeps constructors clean, centralizes socket creation and error handling.
    private static DatagramSocket createSocket() {
        try {
            return new DatagramSocket();
        } catch(SocketException e) {
            throw new IllegalStateException("Unable to create DatagramSocket", e);
        }
    }

    //centralize error handling for constructors
    private static void validateArguments(InetAddress serverAddress, int port, DatagramSocket socket) {
        if(serverAddress == null) {
            throw new IllegalArgumentException("serverAddress must not be null");
        }
        if(socket == null) {
            throw new IllegalArgumentException("socket must not be null");
        }
        if(port < 1 || port > 65535) {
            throw new IllegalArgumentException("Port must be between 1 and 65535");
        }
    }
}
