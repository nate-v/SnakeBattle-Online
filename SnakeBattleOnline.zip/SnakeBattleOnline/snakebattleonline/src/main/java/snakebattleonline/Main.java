package snakebattleonline;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Arrays;
import java.nio.ByteBuffer;

import javax.swing.*;

/*
    TO DO: Remove 1234 default port number before pushing release.
*/

public class Main {
    // Graphics
    private static JFrame frame;
    private static JPanel panel;
    private static JLabel ipLabel;
    private static JTextField ipField;
    private static JLabel portLabel;
    private static JTextField portField;
    private static JButton joinButton;

    private static InetAddress serverAddress;
    private static InetAddress localHost;
    private static int serverPort;

    private static int snakeNum;

    public static void main(String[] args) {
        try {
            localHost = InetAddress.getLocalHost();
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        frame = new JFrame("Snake Battle Online - Connect");
        panel = new JPanel();

        portLabel = new JLabel("Port:");
        portField = new JTextField("1234", 4);
        ipLabel = new JLabel("Server IP:");
        ipField = new JTextField(localHost.getHostAddress(), 15);
        //.substring(0, localHost.getHostAddress().lastIndexOf(".")) + ".##"
        joinButton = new JButton("Join Server");

        panel.add(portLabel);
        panel.add(portField);
        panel.add(ipLabel);
        panel.add(ipField);
        panel.add(joinButton);

        frame.add(panel);
        frame.setSize(400, 120);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        joinButton.addActionListener(e -> {
            try {
                serverPort = Integer.parseInt(portField.getText());
                serverAddress = InetAddress.getByName(ipField.getText());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Invalid port number!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Error occurred while connecting to the server!", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }
            frame.dispose();
            DatagramSocket ds;
            try {
                ds = new DatagramSocket();
                NetworkBroadcaster nb = new NetworkBroadcaster(serverAddress, serverPort, ds);
                nb.broadcast("Connected".getBytes());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Error occured while connecting to server!", "Error",
                        JOptionPane.ERROR_MESSAGE);
                main(null);
                return;
            }
            try {
                byte[] buffer = new byte[1024];
                DatagramPacket dp = new DatagramPacket(buffer, buffer.length);
                ds.setSoTimeout(500);
                ds.receive(dp);
                byte[] data = Arrays.copyOf(dp.getData(), dp.getLength());
                
                snakeNum = ByteBuffer.wrap(data).getInt();
                ds.setSoTimeout(0);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Error occured while connecting to server!", "Error",
                        JOptionPane.ERROR_MESSAGE);
                main(null);
                return;
            }
            
            if(snakeNum == -1) {
                JOptionPane.showMessageDialog(frame, "Server is full!", "Error",
                        JOptionPane.ERROR_MESSAGE);
                main(null);
                return;
            }   else {
                Client client = new Client(serverAddress, serverPort, snakeNum, ds);
            }
        });
    }
}
