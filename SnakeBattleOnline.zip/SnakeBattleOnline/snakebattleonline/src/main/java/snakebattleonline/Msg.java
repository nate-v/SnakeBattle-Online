package snakebattleonline;

public class Msg {
    public static final byte PREGAME = 0;
    public static final byte GAME_STATE = 1;
    public static final byte START_GAME = 2;
}
