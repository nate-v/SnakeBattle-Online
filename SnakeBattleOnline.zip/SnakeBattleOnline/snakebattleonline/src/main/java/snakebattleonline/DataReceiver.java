package snakebattleonline;

import java.net.InetAddress;
public interface DataReceiver {
    void onReceive(byte[] data, InetAddress address, int port);
}
