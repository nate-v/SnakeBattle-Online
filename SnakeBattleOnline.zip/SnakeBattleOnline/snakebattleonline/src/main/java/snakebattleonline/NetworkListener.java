package snakebattleonline;

/* ▄▄     ▄▄▄                 ▄▄▄             ▄▄                  
   ██▄   ██▀      █▄         █▀██  ██▀▀        ██              █▄ 
   ███▄  ██      ▄██▄          ██  ██       ▀▀ ██ ▀▀ ▄▄     ▀▀▄██▄
   ██ ▀█▄██ ▄▀▀█▄ ██ ▄█▀█▄     ██  ██ ▄▀▀█▄ ██ ██ ██ ██ ▄█▀ ██ ██ 
   ██   ▀██ ▄█▀██ ██ ██▄█▀     ██▄ ██ ▄█▀██ ██ ██ ██ ████   ██ ██ 
 ▀██▀    ██▄▀█▄██▄██▄▀█▄▄▄      ▀███▀▄▀█▄██▄██▄██▄██▄██ ▀█▄▄██▄██

    TO DO:
    
*/

/*
    IN ORDER TO IMPLEMENT ON THE FCPS NETWORK:
    1. Open command prompt, run "ipconfig" and feed the IPv4 address
        into the ip variable in the constructor. NetworkListener does
        not need the ip because it listens on the port, not the address.
    2. Allow your JDK through the firewall, it likely will not prompt you.
        You must have administrator access. If you are on JGrasp, the
        bundled JDK is located in C:\Program Files(x86)\jGrasp\bundled\bin
        Allow java.exe and javaw.exe through the firewell for both private 
        and public networks.
    3. The port number can be whatever you want. It will crash if the port
        number is already in use. Open command prompt and run "netstat -a -n -o"
        to see all active ports. Do not use any ports in the UDP section.
    4. If it still does not work, create a new inbound rule by going to control panel ->
        system and security -> advanced settings -> inbound rules -> new inbound rule.
        Choose port, UDP, and either allow a specific port or all of them through public
        and private.
    5. After configuring your network, if it still does not work, check your implementation.

        TIP:
            If you want the server to talk back to clients without a fixed
            client port written into the server. Give the networklistener
            and the networkbroadcaster the same datagramsocket in the 
            constructor. OR you can seperately send client port and address
            information.

            Use ByteArray streams to send larger data packets with mulitple 
            variables.

    You can find a sample implementation of the NetworkListener and NetworkBroadcaster
    in the Server and Client classes provided in this folder.
*/

import java.io.IOException;
import java.net.*;
import java.util.Arrays;

public class NetworkListener extends Thread {
    private final int port;
    private final int packet_size;
    private volatile boolean active = true;
    private DatagramSocket ds;
    private final DataReceiver receiver;

    /*
        CONSTRUCTORS
            - socket is optional, if not provided a new socket is made.
            - socket may be used for sharing a socket across classes (recommended).
    */
    public NetworkListener(int port, int packet_size, DataReceiver receiver) {
        if(port < 1 || port > 65535) {
            throw new IllegalArgumentException("Port must be between 1 and 65535");
        }
        if(packet_size <= 0) {
            throw new IllegalArgumentException("packet_size must be positive");
        }
        if(receiver == null) {
            throw new IllegalArgumentException("receiver must not be null");
        }
        this.port = port;
        this.packet_size = packet_size;
        this.receiver = receiver;
    }

    public NetworkListener(DatagramSocket socket, int packet_size, DataReceiver receiver) {
        if(socket == null) {
            throw new IllegalArgumentException("socket must not be null");
        }
        if(packet_size <= 0) {
            throw new IllegalArgumentException("packet_size must be positive");
        }
        if(receiver == null) {
            throw new IllegalArgumentException("receiver must not be null");
        }
        this.ds = socket;
        this.port = socket.getLocalPort();
        this.packet_size = packet_size;
        this.receiver = receiver;
    }

    /*
        MAIN FUNCTIONALITY
    */
    @Override
    public void run() {
        try {
            if(ds == null) {
                ds = new DatagramSocket(port);
            }
            byte[] buffer = new byte[packet_size];
            DatagramPacket dp = new DatagramPacket(buffer, buffer.length);
            while(active) {
                ds.receive(dp);
                byte[] data = Arrays.copyOf(dp.getData(), dp.getLength());
                receiver.onReceive(data, dp.getAddress(), dp.getPort());
            }
        } catch(SocketException e) {
            if(active) {
                e.printStackTrace();
            }
        } catch(IOException e) {
            e.printStackTrace();
        } finally {
            if(ds != null && !ds.isClosed()) {
                ds.close();
            }
        }
    }

    /*
        CLOSURE AND UTILITIES
     */
    //Centralize logic for shutting down listeners.
    //Returns true if shutdown was successful, false if it was already inactive.
    public boolean shutdown() {
        if(ds != null) {
            ds.close();
            active = false;
            return true;
        }
        return false;
    }
}