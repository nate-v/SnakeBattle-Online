package snakebattleonline;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.awt.image.BufferedImage;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.Queue;

/*

    TO DO:

        Add functionality for players leaving.
        Clean up code and add docs

        



*/

public class Client {
    Random rand = new Random();
    private JFrame frame;
    private JPanel p;
    private javax.swing.Timer timer;
    // private int framesElapsed = 0;

    InputMap im;
    ActionMap am;

    private int snakeNum = -1; // 1-4, assigned by server
                               // each client
    // private InetAddress localHost;
    private InetAddress serverAddress;
    private int serverPort;
    private DatagramSocket sharedSocket; // for sharing the socket with NetworkBroadcaster
    private NetworkBroadcaster nb;

    // Game state variables
    private boolean gameStarted = false;
    private int playersConnected = 1; // 1-4, assigned by server

    // border is 2
    private static int[] snake1Pos = { 2, 35 };
    private static int[] snake2Pos = { 61, 4 };
    private static int[] snake3Pos = { 2, 30 };
    private static int[] snake4Pos = { 61, 35 };
    private static boolean[] death = { false, false, false, false };
    private static int[] wins = { 0, 0, 0, 0 };
    private static boolean resetLatch = false;

    private static ArrayList<int[]> snake1Body = new ArrayList<>();
    private static ArrayList<int[]> snake2Body = new ArrayList<>();
    private static ArrayList<int[]> snake3Body = new ArrayList<>();
    private static ArrayList<int[]> snake4Body = new ArrayList<>();
    private static int[] applePos = { -1, -1 };
    private static boolean goldenApple = false;
    private static int[] snakeLengths = { 4, 4, 4, 4 };

    private dir lastMove = dir.RIGHT;
    private Queue<dir> moveQ = new ArrayDeque<>();
    private static dir[] snakeDirs = { dir.RIGHT, dir.LEFT, dir.RIGHT, dir.LEFT };

    // Images
    private BufferedImage snake, snake2, snake3, snake4, apple, goldenapple, p1wait, p2wait, p3wait, p4wait, wall,
            randomdir, freeze, portal1, portal2, blindness;

    // sounds
    private HashMap<String, Clip> sfx = new HashMap<>();
    private String[] sfiles = { "snakebattleonline/src/main/resources/sounds/death.wav",
            "snakebattleonline/src/main/resources/sounds/apple.wav",
            "snakebattleonline/src/main/resources/sounds/break.wav",
            "snakebattleonline/src/main/resources/sounds/move.wav" };

    // powerups
    private static Powerup powerup = new Powerup();
    private static int powerupType;
    private static int powerupX;
    private static int powerupY;
    private static int powerupOX;
    private static int powerupOY;
    private static boolean isBlind = false;
    private static boolean[] isFrozen = { false, false, false, false };
    private static boolean[] frozenThisFrame = { false, false, false, false };

    // quickchats
    private static int qcPanel = 0;
    // 0 no panel
    // 1 greetings
    // 2 celebrations
    // 3 apologies
    // 4 trash talk
    private int qcOption = 0;
    private String[][] qcStrings = {
            { "Hello!!", "What's up?", "An apple a day keeps the doctor away!", "I'm hungry!" }, // greetings
            { "Yes!", "Nice one!", "How about dem apples?", "GG" }, // celebrations
            { "Sorry!", "Oops!!", "My bad...", "My fault!" }, // apologies
            { "EZ!", "Better luck next time.", "Get on my level!", ";)" } // trash talk
    };
    private String qcString = "";
    private String[] allQCStrings = { "", "", "", "" };

    public Client(InetAddress serverAddress, int serverPort, int snakeNum, DatagramSocket existingSocket) {
        this.serverAddress = serverAddress;
        this.serverPort = serverPort;
        this.snakeNum = snakeNum;
        this.sharedSocket = existingSocket;
        // try {
        // localHost = InetAddress.getLocalHost();
        // } catch (Exception e) {
        // e.printStackTrace();
        // }
        // if server is found and connection is successful, initialize the game
        initialize();
    }

    public void initialize() {
        // initialize powerup to avoid null pointers in paint
        powerup.generate(-1, -1, -1);

        // sounds
        loadSounds();

        // images
        try {
            snake = ImageIO.read(new File("snakebattleonline/src/main/resources/textures/snake.jpg"));
            snake2 = ImageIO.read(new File("snakebattleonline/src/main/resources/textures/snake2.jpg"));
            snake3 = ImageIO.read(new File("snakebattleonline/src/main/resources/textures/snake3.jpg"));
            snake4 = ImageIO.read(new File("snakebattleonline/src/main/resources/textures/snake4.jpg"));
            apple = ImageIO.read(new File("snakebattleonline/src/main/resources/textures/apple.jpg"));
            goldenapple = ImageIO.read(new File("snakebattleonline/src/main/resources/textures/goldenapple.jpg"));
            p1wait = ImageIO.read(new File("snakebattleonline/src/main/resources/textures/player1waiting.jpg"));
            p2wait = ImageIO.read(new File("snakebattleonline/src/main/resources/textures/player2waiting.jpg"));
            p3wait = ImageIO.read(new File("snakebattleonline/src/main/resources/textures/player3waiting.jpg"));
            p4wait = ImageIO.read(new File("snakebattleonline/src/main/resources/textures/player4waiting.jpg"));
            wall = ImageIO.read(new File("snakebattleonline/src/main/resources/textures/wall.jpg"));
            randomdir = ImageIO.read(new File("snakebattleonline/src/main/resources/textures/randomdir.jpg"));
            freeze = ImageIO.read(new File("snakebattleonline/src/main/resources/textures/freeze.jpg"));
            portal1 = ImageIO.read(new File("snakebattleonline/src/main/resources/textures/portal1.jpg"));
            portal2 = ImageIO.read(new File("snakebattleonline/src/main/resources/textures/portal2.jpg"));
            blindness = ImageIO.read(new File("snakebattleonline/src/main/resources/textures/blindness.jpg"));
        } catch (IOException e) {
            System.err.println("Failed to load image: " + e.getMessage());
        }
        BufferedImage[] snakes = { snake, snake2, snake3, snake4 };

        // frame
        frame = new JFrame("Snake Battle Online");
        frame.setUndecorated(true);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        GraphicsDevice gd = ge.getDefaultScreenDevice();
        if (gd.isFullScreenSupported()) {
            gd.setFullScreenWindow(frame);
        }

        // panel
        p = new JPanel() {
            @Override
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(Color.black);
                p.setBackground(Color.gray.darker().darker());
                g2.fillRect(60, 60, 60 * 30, 36 * 30);
                if (!gameStarted) {
                    if (!resetLatch) {
                        resetGameState();
                        resetLatch = true;
                    }
                    if (snakeNum == 1) {
                        g2.drawImage(p1wait, frame.getWidth() / 2 - p1wait.getWidth() / 2,
                                frame.getHeight() / 2 - p1wait.getHeight() / 2, null);
                    } else if (snakeNum == 2) {
                        g2.drawImage(p2wait, frame.getWidth() / 2 - p2wait.getWidth() / 2,
                                frame.getHeight() / 2 - p2wait.getHeight() / 2, null);
                    } else if (snakeNum == 3) {
                        g2.drawImage(p3wait, frame.getWidth() / 2 - p3wait.getWidth() / 2,
                                frame.getHeight() / 2 - p3wait.getHeight() / 2, null);
                    } else if (snakeNum == 4) {
                        g2.drawImage(p4wait, frame.getWidth() / 2 - p4wait.getWidth() / 2,
                                frame.getHeight() / 2 - p4wait.getHeight() / 2, null);
                    }
                    if (playersConnected == 1) {
                        g2.drawImage(snakes[0], frame.getWidth() / 2 - snakes[0].getWidth() / 2,
                                frame.getHeight() / 2 - snakes[0].getHeight() / 2, null);
                    } else if (playersConnected == 2) {
                        g2.drawImage(snakes[0], frame.getWidth() / 2 - snakes[0].getWidth() / 2 - 100,
                                frame.getHeight() / 2 - snakes[0].getHeight() / 2, null);
                        g2.drawImage(snakes[1], frame.getWidth() / 2 - snakes[1].getWidth() / 2 + 100,
                                frame.getHeight() / 2 - snakes[1].getHeight() / 2, null);
                    } else if (playersConnected == 3) {
                        g2.drawImage(snakes[0], frame.getWidth() / 2 - snakes[0].getWidth() / 2 - 150,
                                frame.getHeight() / 2 - snakes[0].getHeight() / 2, null);
                        g2.drawImage(snakes[1], frame.getWidth() / 2 - snakes[1].getWidth() / 2,
                                frame.getHeight() / 2 - snakes[1].getHeight() / 2, null);
                        g2.drawImage(snakes[2], frame.getWidth() / 2 - snakes[2].getWidth() / 2 + 150,
                                frame.getHeight() / 2 - snakes[2].getHeight() / 2, null);
                    } else if (playersConnected == 4) {
                        g2.drawImage(snakes[0], frame.getWidth() / 2 - snakes[0].getWidth() / 2 - 150,
                                frame.getHeight() / 2 - snakes[0].getHeight() / 2, null);
                        g2.drawImage(snakes[1], frame.getWidth() / 2 - snakes[1].getWidth() / 2 - 50,
                                frame.getHeight() / 2 - snakes[1].getHeight() / 2, null);
                        g2.drawImage(snakes[2], frame.getWidth() / 2 - snakes[2].getWidth() / 2 + 50,
                                frame.getHeight() / 2 - snakes[2].getHeight() / 2, null);
                        g2.drawImage(snakes[3], frame.getWidth() / 2 - snakes[3].getWidth() / 2 + 150,
                                frame.getHeight() / 2 - snakes[3].getHeight() / 2, null);
                    }
                } else {
                    resetLatch = false;
                    // draw game
                    // draw powerup
                    switch (powerup.getType()) {
                        case -1 -> {
                        }
                        case 1 -> g2.drawImage(freeze, powerup.getX() * 30, powerup.getY() * 30, null);
                        case 2 -> g2.drawImage(blindness, powerup.getX() * 30, powerup.getY() * 30, null);
                        case 3 -> {
                            g2.drawImage(portal1, powerup.getX() * 30, powerup.getY() * 30, null);
                            g2.drawImage(portal2, powerup.getOtherX() * 30, powerup.getOtherY() * 30, null);
                        }
                        case 4 -> g2.drawImage(randomdir, powerup.getX() * 30, powerup.getY() * 30, null);
                    }
                    // draw the snakes
                    if (playersConnected >= 1 && !death[0]) {
                        g2.drawImage(snakes[0], snake1Pos[0] * 30, snake1Pos[1] * 30, null);
                        for (int[] Body : snake1Body) {
                            g2.drawImage(snakes[0], Body[0] * 30, Body[1] * 30, null);
                        }
                    }
                    if (playersConnected >= 2 && !death[1]) {
                        g2.drawImage(snakes[1], snake2Pos[0] * 30, snake2Pos[1] * 30, null);
                        for (int[] Body : snake2Body) {
                            g2.drawImage(snakes[1], Body[0] * 30, Body[1] * 30, null);
                        }
                    }
                    if (playersConnected >= 3 && !death[2]) {
                        g2.drawImage(snakes[2], snake3Pos[0] * 30, snake3Pos[1] * 30, null);
                        for (int[] Body : snake3Body) {
                            g2.drawImage(snakes[2], Body[0] * 30, Body[1] * 30, null);
                        }
                    }
                    if (playersConnected == 4 && !death[3]) {
                        g2.drawImage(snakes[3], snake4Pos[0] * 30, snake4Pos[1] * 30, null);
                        for (int[] Body : snake4Body) {
                            g2.drawImage(snakes[3], Body[0] * 30, Body[1] * 30, null);
                        }
                    }
                    // draw the apple
                    if (applePos[0] != -1) {
                        if (!goldenApple) {
                            g2.drawImage(apple, applePos[0] * 30, applePos[1] * 30, null);
                        } else {
                            g2.drawImage(goldenapple, applePos[0] * 30, applePos[1] * 30, null);
                        }
                    }
                    if (isBlind) {
                        for (int i = 2; i < 62; i++) {
                            for (int j = 2; j < 38; j++) {
                                int x = -1, y = -1;
                                if (snakeNum == 1) {
                                    x = snake1Pos[0];
                                    y = snake1Pos[1];
                                } else if (snakeNum == 2) {
                                    x = snake2Pos[0];
                                    y = snake2Pos[1];
                                } else if (snakeNum == 3) {
                                    x = snake3Pos[0];
                                    y = snake3Pos[1];
                                } else if (snakeNum == 4) {
                                    x = snake4Pos[0];
                                    y = snake4Pos[1];
                                }
                                if (Math.abs(x - i) > 3 || Math.abs(y - j) > 3) {
                                    g2.drawImage(wall, i * 30, j * 30, null);
                                }
                            }
                        }
                    }
                }
                Font f = new Font("Arial", Font.BOLD, 40);
                FontMetrics fm = g2.getFontMetrics(f);
                g2.setFont(f);
                if (playersConnected > 0) {
                    g2.setColor(Color.GREEN);
                    g2.drawString(String.valueOf(wins[0]), 20, 45);
                }
                if (playersConnected > 0) {
                    g2.setColor(Color.PINK);
                    String temp = String.valueOf(wins[1]);
                    g2.drawString(temp, 1900 - fm.stringWidth(temp), 45);
                }
                if (playersConnected > 0) {
                    g2.setColor(Color.WHITE);
                    g2.drawString(String.valueOf(wins[2]), 20, 1180);
                }
                if (playersConnected > 0) {
                    g2.setColor(Color.BLUE);
                    String temp = String.valueOf(wins[3]);
                    g2.drawString(temp, 1900 - fm.stringWidth(temp), 1180);
                }
                if (qcPanel != 0) {
                    g2.setColor(Color.BLACK);
                    g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.7f));
                    g2.drawRect(60, 60, 290, 160);
                    g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
                    g2.setColor(Color.YELLOW);
                    g2.setFont(new Font("Arial", Font.BOLD, 16));
                    if (qcPanel == 1) {
                        g2.drawString("Greetings:", 70, 80);
                        g2.setFont(new Font("Arial", Font.BOLD, 12));
                        g2.drawString("1: Hello!!", 80, 100);
                        g2.drawString("2: What's up?", 80, 120);
                        g2.drawString("3: An apple a day keeps the doctor away!", 80, 140);
                        g2.drawString("4: I'm hungry!", 80, 160);
                    } else if (qcPanel == 2) {
                        g2.drawString("Celebrations:", 70, 80);
                        g2.setFont(new Font("Arial", Font.BOLD, 12));
                        g2.drawString("1: Yes!", 80, 100);
                        g2.drawString("2: Nice one!", 80, 120);
                        g2.drawString("3: How about dem apples?", 80, 140);
                        g2.drawString("4: GG", 80, 160);
                    } else if (qcPanel == 3) {
                        g2.drawString("Apologies:", 70, 80);
                        g2.setFont(new Font("Arial", Font.BOLD, 12));
                        g2.drawString("1: Sorry!", 80, 100);
                        g2.drawString("2: Oops!!", 80, 120);
                        g2.drawString("3: My bad...", 80, 140);
                        g2.drawString("4: My fault!", 80, 160);
                    } else if (qcPanel == 4) {
                        g2.drawString("Trash Talk:", 70, 80);
                        g2.setFont(new Font("Arial", Font.BOLD, 12));
                        g2.drawString("1: EZ", 80, 100);
                        g2.drawString("2: Better luck next time.", 80, 120);
                        g2.drawString("3: Get on my level!", 80, 140);
                        g2.drawString("4: ;)", 80, 160);
                    }
                    g2.drawString("0: Close)", 80, 180);
                }
                g2.setFont(new Font("Arial", Font.BOLD, 20));
                FontMetrics fmqc = g2.getFontMetrics();
                String qc0 = allQCStrings[0];
                if (qc0 != null && !qc0.isEmpty()) {
                    int x, y, dx, dy;
                    x = snake1Pos[0] * 30 + 15;
                    y = snake1Pos[1] * 30 - 15;
                    dx = fmqc.stringWidth(qc0);
                    dy = fmqc.getAscent() - fmqc.getHeight() / 2;

                    g2.setColor(Color.BLACK);
                    g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.7f));
                    g2.fillRect(x - dx / 2 - 5, y - dy - 5, dx + 10, dy + 20);

                    g2.setColor(Color.GREEN);
                    g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
                    g2.drawString(qc0, x - dx / 2, y + dy);
                }
                String qc1 = allQCStrings[1];
                if (qc1 != null && !qc1.isEmpty()) {
                    int x, y, dx, dy;
                    x = snake2Pos[0] * 30 + 15;
                    y = snake2Pos[1] * 30 - 15;
                    dx = fmqc.stringWidth(qc1);
                    dy = fmqc.getAscent() - fmqc.getHeight() / 2;

                    g2.setColor(Color.BLACK);
                    g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.7f));
                    g2.fillRect(x - dx / 2 - 5, y - dy - 5, dx + 10, dy + 20);

                    g2.setColor(Color.PINK);
                    g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
                    g2.drawString(qc1, x - dx / 2, y + dy);
                }
                String qc2 = allQCStrings[2];
                if (qc2 != null && !qc2.isEmpty()) {
                    String qc = qc2;
                    int x, y, dx, dy;
                    x = snake3Pos[0] * 30 + 15;
                    y = snake3Pos[1] * 30 - 15;
                    dx = fmqc.stringWidth(qc);
                    dy = fmqc.getAscent() - fmqc.getHeight() / 2;

                    g2.setColor(Color.BLACK);
                    g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.7f));
                    g2.fillRect(x - dx / 2 - 5, y - dy - 5, dx + 10, dy + 20);

                    g2.setColor(Color.CYAN);
                    g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
                    g2.drawString(qc, x - dx / 2, y + dy);
                }
                String qc3 = allQCStrings[3];
                if (qc3 != null && !qc3.isEmpty()) {
                    String qc = qc3;
                    int x, y, dx, dy;
                    x = snake4Pos[0] * 30 + 15;
                    y = snake4Pos[1] * 30 - 15;
                    dx = fmqc.stringWidth(qc);
                    dy = fmqc.getAscent() - fmqc.getHeight() / 2;

                    g2.setColor(Color.BLACK);
                    g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.7f));
                    g2.fillRect(x - dx / 2 - 5, y - dy - 5, dx + 10, dy + 20);

                    g2.setColor(Color.MAGENTA);
                    g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
                    g2.drawString(qc, x - dx / 2, y + dy);
                }
            }
        };
        frame.add(p);
        p.repaint();
        frame.setVisible(true);
        frame.requestFocusInWindow();

        im = p.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        am = p.getActionMap();

        /*
         * WASD and Arrow keys will both map to the same actions.
         */
        im.put(KeyStroke.getKeyStroke("pressed RIGHT"), "rightPressed");
        im.put(KeyStroke.getKeyStroke("pressed DOWN"), "downPressed");
        im.put(KeyStroke.getKeyStroke("pressed LEFT"), "leftPressed");
        im.put(KeyStroke.getKeyStroke("pressed UP"), "upPressed");
        im.put(KeyStroke.getKeyStroke('w'), "wPressed");
        im.put(KeyStroke.getKeyStroke('a'), "aPressed");
        im.put(KeyStroke.getKeyStroke('s'), "sPressed");
        im.put(KeyStroke.getKeyStroke('d'), "dPressed");
        im.put(KeyStroke.getKeyStroke(' '), "spacePressed");

        // lol quickchat
        im.put(KeyStroke.getKeyStroke('1'), "qc1");
        im.put(KeyStroke.getKeyStroke('2'), "qc2");
        im.put(KeyStroke.getKeyStroke('3'), "qc3");
        im.put(KeyStroke.getKeyStroke('4'), "qc4");
        im.put(KeyStroke.getKeyStroke('0'), "qcexit");

        am.put("rightPressed",
                new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (lastMove != dir.LEFT && lastMove != dir.RIGHT && gameStarted && !isFrozen[snakeNum - 1]) {
                            moveQ.add(dir.RIGHT);
                            lastMove = dir.RIGHT;
                            playSound("move");
                        }
                    }
                });
        am.put("downPressed",
                new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (lastMove != dir.UP && lastMove != dir.DOWN && gameStarted && !isFrozen[snakeNum - 1]) {
                            moveQ.add(dir.DOWN);
                            lastMove = dir.DOWN;
                            playSound("move");
                        }
                    }
                });
        am.put("leftPressed",
                new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (lastMove != dir.LEFT && lastMove != dir.RIGHT && gameStarted && !isFrozen[snakeNum - 1]) {
                            moveQ.add(dir.LEFT);
                            lastMove = dir.LEFT;
                            playSound("move");
                        }
                    }
                });
        am.put("upPressed",
                new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (lastMove != dir.DOWN && lastMove != dir.UP && gameStarted && !isFrozen[snakeNum - 1]) {
                            moveQ.add(dir.UP);
                            lastMove = dir.UP;
                            playSound("move");
                        }
                    }
                });
        am.put("wPressed",
                new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (lastMove != dir.DOWN && lastMove != dir.UP && gameStarted && !isFrozen[snakeNum - 1]) {
                            moveQ.add(dir.UP);
                            lastMove = dir.UP;
                            playSound("move");
                        }
                    }
                });
        am.put("aPressed",
                new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (lastMove != dir.LEFT && lastMove != dir.RIGHT && gameStarted && !isFrozen[snakeNum - 1]) {
                            moveQ.add(dir.LEFT);
                            lastMove = dir.LEFT;
                            playSound("move");
                        }
                    }
                });
        am.put("sPressed",
                new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (lastMove != dir.UP && lastMove != dir.DOWN && gameStarted && !isFrozen[snakeNum - 1]) {
                            moveQ.add(dir.DOWN);
                            lastMove = dir.DOWN;
                            playSound("move");
                        }
                    }
                });
        am.put("dPressed",
                new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (lastMove != dir.LEFT && lastMove != dir.RIGHT && gameStarted && !isFrozen[snakeNum - 1]) {
                            moveQ.add(dir.RIGHT);
                            lastMove = dir.RIGHT;
                            playSound("move");
                        }
                    }
                });
        am.put("spacePressed",
                new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (snakeNum == 1 && !gameStarted && playersConnected >= 2) {
                            nb.broadcast("Start game".getBytes());
                        }
                    }
                });
        am.put("qc1",
                new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (qcPanel == 0) {
                            qcPanel = 1;
                        } else {
                            qcOption = 1;
                            qcString = qcStrings[qcPanel - 1][qcOption - 1];
                            qcOption = 0;
                            qcPanel = 0;
                        }
                    }
                });
        am.put("qc2",
                new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (qcPanel == 0) {
                            qcPanel = 2;
                        } else {
                            qcOption = 2;
                            qcString = qcStrings[qcPanel - 1][qcOption - 1];
                            qcOption = 0;
                            qcPanel = 0;
                        }
                    }
                });
        am.put("qc3",
                new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (qcPanel == 0) {
                            qcPanel = 3;
                        } else {
                            qcOption = 3;
                            qcString = qcStrings[qcPanel - 1][qcOption - 1];
                            qcOption = 0;
                            qcPanel = 0;
                        }
                    }
                });
        am.put("qc4",
                new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (qcPanel == 0) {
                            qcPanel = 4;
                        } else {
                            qcOption = 4;
                            qcString = qcStrings[qcPanel - 1][qcOption - 1];
                            qcOption = 0;
                            qcPanel = 0;
                        }
                    }
                });
        am.put("qcexit",
                new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        qcPanel = 0;
                        qcString = "";

                    }
                });

        // Network listener
        try {
            this.nb = new NetworkBroadcaster(serverAddress, serverPort, sharedSocket);

            // Send the listening port to the server so it knows where to send game updates
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(baos);

            NetworkListener nl = new NetworkListener(sharedSocket, 1024, new DataReceiver() {
                @Override
                public void onReceive(byte[] data, InetAddress address, int port) {
                    SwingUtilities.invokeLater(() -> {
                        ByteArrayInputStream bais = new ByteArrayInputStream(data);
                        DataInputStream dis = new DataInputStream(bais);
                        if (new String(data).equals("Server stopped")) {
                            JOptionPane.showMessageDialog(frame, "Server has disconnected or stopped!", "Game Over",
                                    JOptionPane.INFORMATION_MESSAGE);
                            frame.dispose();
                            System.exit(0);
                            return;
                        }
                        boolean tempDeath[] = new boolean[] { death[0], death[1], death[2], death[3] };
                        try {
                            gameStarted = dis.readBoolean();
                            playersConnected = dis.readInt();
                            snake1Pos = new int[] { dis.readInt(), dis.readInt() };
                            snakeLengths[0] = dis.readInt();
                            snake2Pos = new int[] { dis.readInt(), dis.readInt() };
                            snakeLengths[1] = dis.readInt();
                            snake3Pos = new int[] { dis.readInt(), dis.readInt() };
                            snakeLengths[2] = dis.readInt();
                            snake4Pos = new int[] { dis.readInt(), dis.readInt() };
                            snakeLengths[3] = dis.readInt();
                            applePos = new int[] { dis.readInt(), dis.readInt() };
                            goldenApple = dis.readBoolean();
                            death[0] = dis.readBoolean();
                            death[1] = dis.readBoolean();
                            death[2] = dis.readBoolean();
                            death[3] = dis.readBoolean();
                            wins[0] = dis.readInt();
                            wins[1] = dis.readInt();
                            wins[2] = dis.readInt();
                            wins[3] = dis.readInt();
                            // quickchats
                            allQCStrings[0] = dis.readUTF();
                            allQCStrings[1] = dis.readUTF();
                            allQCStrings[2] = dis.readUTF();
                            allQCStrings[3] = dis.readUTF();
                            // powerups
                            powerupType = dis.readInt();
                            powerupX = dis.readInt();
                            powerupY = dis.readInt();
                            powerupOX = dis.readInt();
                            powerupOY = dis.readInt();
                            isFrozen[0] = dis.readBoolean();
                            isFrozen[1] = dis.readBoolean();
                            isFrozen[2] = dis.readBoolean();
                            isFrozen[3] = dis.readBoolean();
                            for (int s = 0; s < 4; s++) {
                                if (snakeNum - 1 == s) {
                                    isBlind = dis.readBoolean();
                                    break;
                                }
                                dis.readBoolean();
                            } // This for statement does not always read
                              // all 4 isBlind states from the server.
                              // if you read anything after make sure to
                              // take care of that.

                            updateGameState();
                            for (int i = 0; i < 4; i++) {
                                if (tempDeath[i] == false && death[i] == true) {
                                    playSound("death");
                                }
                            }
                            if (moveQ.size() > 0) {
                                snakeDirs[snakeNum - 1] = moveQ.peek();
                            }

                            p.repaint();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    });
                }
            });
            nl.start();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // driver
        timer = new javax.swing.Timer(50,
                new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        updateGame();
                        // framesElapsed++;
                    }

                });
        timer.start();
    }

    private void updateGame() {
        broadcastGameState();
    }

    private void updateGameState() {
        // spawn powerup
        if (powerupType != -1 && powerup.getType() == -1) {
            if (powerupType == 3) {
                powerup.generate(powerupX, powerupY, powerupOX, powerupOY, powerupType);
            } else {
                powerup.generate(powerupX, powerupY, powerupType);
            }
        } else if (powerupType == -1 && powerup.getType() != -1) {
            powerup.generate(-1, -1, -1);
            playSound("apple");
        }
        boolean grownThisFrame = false;
        while (snake1Body.size() < snakeLengths[0]) {
            snake1Body.add(new int[] { -1, -1 });
            if (!grownThisFrame) {
                playSound("apple");
                grownThisFrame = true;
            }
        }
        while (snake2Body.size() < snakeLengths[1]) {
            snake2Body.add(new int[] { -1, -1 });
            if (!grownThisFrame) {
                playSound("apple");
                grownThisFrame = true;
            }
        }
        while (snake3Body.size() < snakeLengths[2]) {
            snake3Body.add(new int[] { -1, -1 });
            if (!grownThisFrame) {
                playSound("apple");
                grownThisFrame = true;
            }
        }
        while (snake4Body.size() < snakeLengths[3]) {
            snake4Body.add(new int[] { -1, -1 });
            if (!grownThisFrame) {
                playSound("apple");
                grownThisFrame = true;
            }
        }
        // movement
        // move tail with head
        if (snake1Body.size() > 0 && frozenThisFrame[0] == false) {
            for (int i = snake1Body.size() - 1; i >= 1; i--) {
                snake1Body.get(i)[0] = snake1Body.get(i - 1)[0];
                snake1Body.get(i)[1] = snake1Body.get(i - 1)[1];
            }
            snake1Body.get(0)[0] = snake1Pos[0];
            snake1Body.get(0)[1] = snake1Pos[1];
        }

        if (snake2Body.size() > 0 && frozenThisFrame[1] == false) {
            for (int i = snake2Body.size() - 1; i >= 1; i--) {
                snake2Body.get(i)[0] = snake2Body.get(i - 1)[0];
                snake2Body.get(i)[1] = snake2Body.get(i - 1)[1];
            }
            snake2Body.get(0)[0] = snake2Pos[0];
            snake2Body.get(0)[1] = snake2Pos[1];
        }

        if (snake3Body.size() > 0 && frozenThisFrame[2] == false) {
            for (int i = snake3Body.size() - 1; i >= 1; i--) {
                snake3Body.get(i)[0] = snake3Body.get(i - 1)[0];
                snake3Body.get(i)[1] = snake3Body.get(i - 1)[1];
            }
            snake3Body.get(0)[0] = snake3Pos[0];
            snake3Body.get(0)[1] = snake3Pos[1];
        }

        if (snake4Body.size() > 0 && frozenThisFrame[3] == false) {
            for (int i = snake4Body.size() - 1; i >= 1; i--) {
                snake4Body.get(i)[0] = snake4Body.get(i - 1)[0];
                snake4Body.get(i)[1] = snake4Body.get(i - 1)[1];
            }
            snake4Body.get(0)[0] = snake4Pos[0];
            snake4Body.get(0)[1] = snake4Pos[1];
        }
        for (int i = 0; i < 4; i++) {
            frozenThisFrame[i] = isFrozen[i];
        }
    }

    private void broadcastGameState() {
        if (!gameStarted || nb == null) {
            return;
        }

        // Get the next direction from the queue if available
        dir directionToSend = snakeDirs[snakeNum - 1];
        if (moveQ.size() != 0) {
            directionToSend = moveQ.poll();
            snakeDirs[snakeNum - 1] = directionToSend;
        }

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        try {
            dos.writeBoolean(gameStarted);
            dos.writeInt(snakeNum);
            dos.writeInt(directionToSend.ordinal());
            dos.writeInt(snakeLengths[snakeNum - 1]);
            dos.writeUTF(qcString == null ? "" : qcString);
            nb.broadcast(baos.toByteArray());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadSounds() {
        String[] soundNames = { "death", "apple", "break", "move" };
        for (int i = 0; i < sfiles.length; i++) {
            try {
                File f = new File(sfiles[i]);
                if (!f.exists()) {
                    System.err.println("Sound file not found: " + sfiles[i]);
                    continue;
                }
                AudioInputStream a_in = AudioSystem.getAudioInputStream(f);
                Clip c = AudioSystem.getClip();
                c.open(a_in);
                sfx.put(soundNames[i], c);
                System.out.println("Successfully loaded sound: " + soundNames[i]);
            } catch (Exception e) {
                System.err.println("Failed to load sound " + soundNames[i] + ": " + e.getMessage());
            }
        }
    }

    private void playSound(String name) {
        Clip clip = sfx.get(name);
        if (clip != null) {
            if (clip.isRunning()) {
                clip.stop();
            }
            clip.setFramePosition(0);
            clip.start();
            System.out.println("Played sound: " + name);
        }
    }

    private void resetGameState() {

        // Game state
        // framesElapsed = 0;
        snake1Pos = null;
        snake2Pos = null;
        snake3Pos = null;
        snake4Pos = null;
        snake1Pos = new int[] { 2, 35 };
        snake2Pos = new int[] { 61, 4 };
        snake3Pos = new int[] { 2, 4 };
        snake4Pos = new int[] { 61, 35 };
        snakeDirs = new dir[] { dir.RIGHT, dir.LEFT, dir.RIGHT, dir.LEFT };

        applePos = new int[] { -1, -1 };
        goldenApple = false;
        snakeLengths = new int[] { 4, 4, 4, 4 };

        death = new boolean[] { false, false, false, false };

        snake1Body.clear();
        snake2Body.clear();
        snake3Body.clear();
        snake4Body.clear();

        moveQ.clear();
        lastMove = (snakeNum == 1 || snakeNum == 3) ? dir.RIGHT : dir.LEFT;
    }
}
